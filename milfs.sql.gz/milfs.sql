-- phpMyAdmin SQL Dump
-- version 4.2.9deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 30, 2014 at 03:26 PM
-- Server version: 5.5.39-1
-- PHP Version: 5.6.0-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `milfs`
--

-- --------------------------------------------------------

--
-- Table structure for table `empresa`
--

CREATE TABLE IF NOT EXISTS `empresa` (
`id` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL DEFAULT '0' COMMENT 'Se guarda el id del responsable de la empresa',
  `ciiu` char(5) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `sector` int(3) NOT NULL,
  `razon_social` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `sigla` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `slogan` text CHARACTER SET latin1 NOT NULL,
  `nit` varchar(15) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `direccion` text CHARACTER SET latin1 NOT NULL,
  `telefono_1` varchar(30) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `web` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `email` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `persona_contacto` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `regimen_tributario` char(15) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `resolucion_facturacion` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `facturacion_desde` int(30) DEFAULT NULL COMMENT 'Comienzo del permiso de facturación',
  `facturacion_hasta` int(30) DEFAULT NULL COMMENT 'Fin del permiso de facturación',
  `facturacion_primera` int(30) DEFAULT NULL COMMENT 'Primera factura que se imprimirá, puede ser la primera de la resolución',
  `facturacion_prefijo` varchar(25) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `facturacion_fecha` int(20) NOT NULL DEFAULT '0' COMMENT 'Fechad e la resolucion',
  `facturacion_vencimiento` int(20) NOT NULL DEFAULT '0' COMMENT 'Fecha de vencimiento de la resolucion de facturación',
  `logo_color` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_bn` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_alta` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_baja` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `imagen` char(40) COLLATE utf8_spanish2_ci NOT NULL,
  `css` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `css_impresion` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `id_localizacion` int(11) NOT NULL,
  `id_redes_sociales` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci COMMENT='Datos de la IPS';

--
-- Dumping data for table `empresa`
--

INSERT INTO `empresa` (`id`, `id_responsable`, `ciiu`, `sector`, `razon_social`, `sigla`, `slogan`, `nit`, `direccion`, `telefono_1`, `web`, `email`, `persona_contacto`, `regimen_tributario`, `resolucion_facturacion`, `facturacion_desde`, `facturacion_hasta`, `facturacion_primera`, `facturacion_prefijo`, `facturacion_fecha`, `facturacion_vencimiento`, `logo_color`, `logo_bn`, `logo_alta`, `logo_baja`, `imagen`, `css`, `css_impresion`, `id_localizacion`, `id_redes_sociales`) VALUES
(1, 1, '', 0, 'Aplicación MILFS', 'MILFS', 'El futuro ya no es lo que era', '', '', '', '', 'proyectos@qwerty.co', '', '', '', NULL, NULL, NULL, '', 0, 0, '', '', '', '', 'ef93d98ad3f043570831df6dd9acba9d.jpg', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `form_campos`
--

CREATE TABLE IF NOT EXISTS `form_campos` (
`id` int(11) NOT NULL,
  `id_especialista` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL,
  `campo_nombre` text CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `campo_descripcion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `campo_tipo` int(11) NOT NULL DEFAULT '0',
  `campo_area` int(11) DEFAULT NULL,
  `orden` int(2) NOT NULL DEFAULT '0',
  `activo` int(11) NOT NULL DEFAULT '0',
  `identificador` varchar(32) NOT NULL,
  `bloqueo` int(1) NOT NULL DEFAULT '0',
  `tipo_contenido` set('1','a','s') NOT NULL COMMENT '''1 numerico'',''alfanumerico'',''simbolos'''
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_campos`
--

INSERT INTO `form_campos` (`id`, `id_especialista`, `id_empresa`, `campo_nombre`, `campo_descripcion`, `campo_tipo`, `campo_area`, `orden`, `activo`, `identificador`, `bloqueo`, `tipo_contenido`) VALUES
(1, 0, 1, 'Primer nombre', 'Pablo', 1, 0, 0, 1, 'f13bb435acfd7ba3f88a5f74fe3fadc2', 0, ''),
(2, 0, 1, 'Segundo nombre', 'Fernando', 1, 0, 0, 1, 'e03db6f72422a01b20953b25d7c7fee3', 0, ''),
(3, 0, 1, 'Primer apellido', 'Perez', 1, 0, 0, 1, '5c3cdc8e15eb15dfce8c591986deb800', 0, ''),
(4, 0, 1, 'Segundo apellido', 'Martinez', 1, 0, 0, 1, 'bc1699111bd9aa3b3ec114f53f99a3cb', 0, ''),
(5, 0, 1, 'Nombres y apellidos', 'Escriba el nombre completo con apellidos', 1, 0, 0, 1, '531a7eaef7ed326a6222e2aeb1229e9c', 0, ''),
(6, 0, 1, 'Telefono', 'Solo números', 3, 0, 0, 1, '4a70495abb15d926dcc031e58b67fbe4', 0, ''),
(7, 0, 1, 'Dirección', 'Escriba la dirección completa', 2, 0, 0, 1, '400864ef5b72242c7aa78edaa83854f3', 0, ''),
(8, 0, 1, 'Actividad', '', 1, 0, 0, 1, 'e92ff0595452708abc9e7bfe698eafd1', 0, ''),
(9, 0, 1, 'Descripcion', 'limitado a 140 caracteres.', 17, 0, 0, 1, '34b1a570180e02f1960e7d7a25e23002', 0, ''),
(10, 0, 1, 'Mes', 'Los meses del año', 8, 0, 0, 1, '400ba32128df67eb162fb753e8cfad4c', 0, ''),
(11, 0, 1, 'Entidad', 'Nombre de la entidad.', 1, 0, 0, 1, '9141fdf92fbed44d18789854b537868e', 0, ''),
(12, 0, 1, 'Cargo', 'Cargo en la empresa, no es un campo obligatorio.', 1, 0, 0, 1, '16011685a8337f9c38e988652969a96f', 0, ''),
(13, 0, 1, 'Celular', 'Numero de celular.', 3, 0, 0, 1, '1a9ca006b88f96785ca15a6165e813ff', 0, ''),
(14, 0, 1, 'Categoria', 'Categoria para los contactos del museo ', 8, 0, 0, 1, '1852d58951a6980771d9ee7ba189722a', 0, ''),
(15, 0, 1, 'Correo electronico', 'Correo electronico', 1, 0, 0, 1, 'dd9fc13c87ca1fbde986c92c131e6b5d', 0, ''),
(16, 0, 1, 'Correo electronico secundario', 'Correo Electronico Secundario, si la persona tiene un segundo correo este campo puede ser útil.', 1, 0, 0, 1, '65e752c9c88fdfba3a1eea293a89e4f3', 0, ''),
(17, 0, 1, 'Ciudad', 'Ciudad relacionada', 1, 0, 0, 1, 'baea0a6f032dc1b9ef3a5e36872d3dc1', 0, ''),
(18, 0, 1, 'Mapa', 'Campo de georeferencia', 14, 0, 0, 1, 'ed76fc240f8e9a4fa980fd76ba1d75e1', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `form_campos_valores`
--

CREATE TABLE IF NOT EXISTS `form_campos_valores` (
`id` int(11) NOT NULL,
  `id_form_campo` int(11) NOT NULL,
  `campo_valor` char(200) COLLATE utf8_spanish2_ci NOT NULL,
  `predeterminado` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `form_campos_valores`
--

INSERT INTO `form_campos_valores` (`id`, `id_form_campo`, `campo_valor`, `predeterminado`) VALUES
(1, 10, 'Enero', '0'),
(2, 10, 'Febrero', '0'),
(3, 10, 'Marzo', '0'),
(4, 10, 'Abril', '0'),
(5, 10, 'Mayo', '0'),
(6, 10, 'Junio', '0'),
(7, 10, 'Julio', '0'),
(8, 10, 'Agosto', '0'),
(9, 10, 'Septiembre', '0'),
(10, 10, 'Octubre', '0'),
(11, 10, 'Noviembre', '0'),
(12, 10, 'Diciembre', '0'),
(13, 14, 'Medio local', '0'),
(15, 14, 'Cooperación', '0'),
(16, 14, 'Amigo', '0'),
(17, 14, 'Privado', '0'),
(18, 14, 'Ong', '0'),
(20, 9, '140', '0');

-- --------------------------------------------------------

--
-- Table structure for table `form_contenido_campos`
--

CREATE TABLE IF NOT EXISTS `form_contenido_campos` (
`id` int(11) NOT NULL,
  `id_campo` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `id_form` int(2) NOT NULL,
  `obligatorio` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `multiple` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `orden` int(2) NOT NULL COMMENT 'orden en que aparecerá cada campo en la cnsulta particular',
  `control` varchar(32) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `form_contenido_campos`
--

INSERT INTO `form_contenido_campos` (`id`, `id_campo`, `id_empresa`, `id_form`, `obligatorio`, `multiple`, `orden`, `control`) VALUES
(1, 8, 1, 1, '0', '0', 64, '6e32ac8d93d1a961ab91d73cfb7575d3'),
(2, 12, 1, 1, '0', '0', 86, '834f71fbbafd7ec4f3ee69e29f03acad'),
(3, 14, 1, 1, '0', '0', 28, '4721b9600b48d52bcea9562e761cdf63'),
(4, 13, 1, 1, '0', '0', 92, '0bf782d4f388d371beac89d0c04add1f'),
(5, 17, 1, 1, '0', '0', 21, '68298143ba7642d8c159bd1e6683fd69'),
(6, 15, 1, 1, '0', '0', 100, 'cab04c8a42502bcc0c09b345626899a8'),
(7, 16, 1, 1, '0', '0', 80, '9ce8a2166c9fbe73db787b2fa3792236'),
(8, 9, 1, 1, '0', '1', 45, '82fea7e28bb6d1c8b662f38917a20105'),
(9, 7, 1, 1, '0', '0', 50, '0c7e879ac516f5bee9bc5a987c81364a'),
(10, 11, 1, 1, '1', '0', 40, '00bee84be8fad0e613a6b7884dc4666b'),
(11, 18, 1, 1, '1', '0', 35, '23b34e9ef1fa1a9bababd422981f1327'),
(12, 10, 1, 1, '0', '0', 75, '0ca2686b829f9e84272e628d9189f7ed'),
(14, 3, 1, 1, '0', '0', 7, '820fb45d7de3a9c89269c1be25b7c370'),
(15, 1, 1, 1, '0', '0', 0, 'c6157909441e8a4ed35f40778ffb6798'),
(16, 4, 1, 1, '0', '0', 8, 'bbe12fe0eea1ac187d7c08d96c6c635a'),
(17, 2, 1, 1, '0', '0', 4, '8d9ffbf53c8f139785ee5e2268eacdcf'),
(18, 6, 1, 1, '0', '0', 87, '1e5b1b8b1b5b0b936652ce98c2f9424c');

-- --------------------------------------------------------

--
-- Table structure for table `form_datos`
--

CREATE TABLE IF NOT EXISTS `form_datos` (
`id` int(11) NOT NULL,
  `id_campo` int(11) DEFAULT NULL,
  `form_id` int(3) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_empresa` int(11) NOT NULL,
  `contenido` text NOT NULL,
  `timestamp` int(20) DEFAULT NULL,
  `ip` int(10) unsigned DEFAULT NULL,
  `control` char(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_datos`
--

INSERT INTO `form_datos` (`id`, `id_campo`, `form_id`, `id_usuario`, `id_empresa`, `contenido`, `timestamp`, `ip`, `control`) VALUES
(1, 8, 1, 1, 1, 'Prueba', 1412107050, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(2, 12, 1, 1, 1, 'Desarrollador', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(3, 13, 1, 1, 1, '3044886255', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(4, 17, 1, 1, 1, 'Bogotá', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(5, 15, 1, 1, 1, 'fredyrivera@gmail.com', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(6, 9, 1, 1, 1, 'Nos vemos en twiiter @fredy_rivera', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(7, 11, 1, 1, 1, 'QWERTY LTDA.', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(8, 18, 1, 1, 1, '-75.5570125579834 6.246374284186 16', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(9, 3, 1, 1, 1, 'Rivera', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(10, 1, 1, 1, 1, 'Fredy', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(11, 6, 1, 1, 1, '3044886255', 1412107051, NULL, 'a2ccd390f4f16f20fd7021029a5eb445'),
(12, 1, 1, 1, 1, 'Alpha', 1412108524, NULL, '15e8a24e2fb1a21af0d14829900a425e'),
(13, 17, 1, 1, 1, 'Filandia', 1412108524, NULL, '15e8a24e2fb1a21af0d14829900a425e'),
(14, 18, 1, 1, 1, '-75.63305854797363 4.687897011181564 14', 1412108524, NULL, '15e8a24e2fb1a21af0d14829900a425e'),
(15, 11, 1, 1, 1, 'Fundación Vivirenlafinca', 1412108524, NULL, '15e8a24e2fb1a21af0d14829900a425e'),
(16, 9, 1, 1, 1, 'Placer de vivir en sábado en la tarde', 1412108524, NULL, '15e8a24e2fb1a21af0d14829900a425e');

-- --------------------------------------------------------

--
-- Table structure for table `form_id`
--

CREATE TABLE IF NOT EXISTS `form_id` (
`id` int(11) NOT NULL,
  `nombre` varchar(60) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish2_ci NOT NULL,
  `activo` set('0','1') COLLATE utf8_spanish2_ci NOT NULL,
  `modificable` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '1',
  `publico` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `propietario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `orden` int(11) NOT NULL,
  `formulario_respuesta` int(3) DEFAULT NULL COMMENT 'Formulario con el que se contesta'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `form_id`
--

INSERT INTO `form_id` (`id`, `nombre`, `descripcion`, `activo`, `modificable`, `publico`, `propietario`, `id_empresa`, `creacion`, `orden`, `formulario_respuesta`) VALUES
(1, 'Contacto', 'Capura de datos en evento.', '1', '1', '1', 1, 1, '2014-09-30 19:47:38', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `form_tipo_campo`
--

CREATE TABLE IF NOT EXISTS `form_tipo_campo` (
`id_tipo_campo` int(11) NOT NULL,
  `tipo_campo_nombre` text NOT NULL,
  `tipo_campo_accion` text NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_tipo_campo`
--

INSERT INTO `form_tipo_campo` (`id_tipo_campo`, `tipo_campo_nombre`, `tipo_campo_accion`, `activo`) VALUES
(1, 'Texto', 'text', 1),
(2, 'Nota', 'textarea', 1),
(3, 'Numérico', 'number', 1),
(4, 'URL', 'url', 1),
(5, 'Medio', 'media', 1),
(8, 'Select', 'select', 1),
(11, 'Fecha', 'date', 1),
(12, 'Email', 'email', 1),
(13, 'Email envío', 'envio', 1),
(14, 'Mapa', 'mapa', 1),
(15, 'Imagen', 'imagen', 1),
(16, 'Rango', 'rango', 1),
(17, 'Texto limitado', 'limit', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
`id` int(32) NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `passwd` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `id_grupo` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `email` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `adddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(3) NOT NULL DEFAULT '0',
  `lastip` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `lastdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `p_nombre` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `s_nombre` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `p_apellido` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `s_apellido` varchar(255) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `nombre_completo` varchar(254) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '',
  `fecha_nacimiento` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `documento_tipo` int(11) NOT NULL DEFAULT '0',
  `documento_numero` char(20) CHARACTER SET latin1 NOT NULL,
  `documento_expedicion` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `control` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `firma_recuperacion` char(40) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `genero` set('M','F') CHARACTER SET latin1 NOT NULL DEFAULT '',
  `cargo` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `fotografia` char(36) COLLATE utf8_spanish2_ci NOT NULL,
  `licencia` text COLLATE utf8_spanish2_ci NOT NULL,
  `licencia_fecha` int(20) DEFAULT '0',
  `bio` longtext COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `passwd`, `id_grupo`, `id_empresa`, `email`, `adddate`, `status`, `lastip`, `lastdate`, `p_nombre`, `s_nombre`, `p_apellido`, `s_apellido`, `nombre_completo`, `fecha_nacimiento`, `documento_tipo`, `documento_numero`, `documento_expedicion`, `control`, `firma_recuperacion`, `genero`, `cargo`, `fotografia`, `licencia`, `licencia_fecha`, `bio`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 0, 1, 'proyectos@qwerty.co', '2014-09-15 22:58:45', 1, '', '0000-00-00 00:00:00', NULL, NULL, 'admin', '', '', '', 0, '', '', NULL, 'b04c7d514202f550685adf97257566e920f50558', '', '', '', '', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `empresa`
--
ALTER TABLE `empresa`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_campos`
--
ALTER TABLE `form_campos`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `identificador` (`identificador`);

--
-- Indexes for table `form_campos_valores`
--
ALTER TABLE `form_campos_valores`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_contenido_campos`
--
ALTER TABLE `form_contenido_campos`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `control` (`control`);

--
-- Indexes for table `form_datos`
--
ALTER TABLE `form_datos`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`), ADD KEY `control` (`control`), ADD KEY `id_campo` (`id_campo`), ADD KEY `perfil` (`form_id`), ADD KEY `id_usuario` (`id_usuario`);

--
-- Indexes for table `form_id`
--
ALTER TABLE `form_id`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_tipo_campo`
--
ALTER TABLE `form_tipo_campo`
 ADD PRIMARY KEY (`id_tipo_campo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `empresa`
--
ALTER TABLE `empresa`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `form_campos`
--
ALTER TABLE `form_campos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `form_campos_valores`
--
ALTER TABLE `form_campos_valores`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `form_contenido_campos`
--
ALTER TABLE `form_contenido_campos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `form_datos`
--
ALTER TABLE `form_datos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `form_id`
--
ALTER TABLE `form_id`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `form_tipo_campo`
--
ALTER TABLE `form_tipo_campo`
MODIFY `id_tipo_campo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
MODIFY `id` int(32) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
