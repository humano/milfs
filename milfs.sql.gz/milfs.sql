-- phpMyAdmin SQL Dump
-- version 4.2.7.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 26, 2014 at 08:55 AM
-- Server version: 5.5.37-1
-- PHP Version: 5.6.0RC4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `milfs`
--

-- --------------------------------------------------------

--
-- Table structure for table `empresa`
--

CREATE TABLE IF NOT EXISTS `empresa` (
`id` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL DEFAULT '0' COMMENT 'Se guarda el id del responsable de la empresa',
  `ciiu` char(5) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `sector` int(3) NOT NULL,
  `razon_social` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `sigla` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `slogan` text CHARACTER SET latin1 NOT NULL,
  `nit` varchar(15) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `direccion` text CHARACTER SET latin1 NOT NULL,
  `telefono_1` varchar(30) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `web` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `email` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `persona_contacto` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `regimen_tributario` char(15) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `resolucion_facturacion` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `facturacion_desde` int(30) DEFAULT NULL COMMENT 'Comienzo del permiso de facturación',
  `facturacion_hasta` int(30) DEFAULT NULL COMMENT 'Fin del permiso de facturación',
  `facturacion_primera` int(30) DEFAULT NULL COMMENT 'Primera factura que se imprimirá, puede ser la primera de la resolución',
  `facturacion_prefijo` varchar(25) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `facturacion_fecha` int(20) NOT NULL DEFAULT '0' COMMENT 'Fechad e la resolucion',
  `facturacion_vencimiento` int(20) NOT NULL DEFAULT '0' COMMENT 'Fecha de vencimiento de la resolucion de facturación',
  `logo_color` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_bn` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_alta` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_baja` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `imagen` char(40) COLLATE utf8_spanish2_ci NOT NULL,
  `css` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `css_impresion` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `id_localizacion` int(11) NOT NULL,
  `id_redes_sociales` int(11) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci COMMENT='Datos de la IPS' AUTO_INCREMENT=41 ;

--
-- Dumping data for table `empresa`
--

INSERT INTO `empresa` (`id`, `id_responsable`, `ciiu`, `sector`, `razon_social`, `sigla`, `slogan`, `nit`, `direccion`, `telefono_1`, `web`, `email`, `persona_contacto`, `regimen_tributario`, `resolucion_facturacion`, `facturacion_desde`, `facturacion_hasta`, `facturacion_primera`, `facturacion_prefijo`, `facturacion_fecha`, `facturacion_vencimiento`, `logo_color`, `logo_bn`, `logo_alta`, `logo_baja`, `imagen`, `css`, `css_impresion`, `id_localizacion`, `id_redes_sociales`) VALUES
(1, 1, '', 0, 'QWERTY Ltda', '', 'MILFS', '', '', '3178946799', 'qwerty.co', 'proyectos@qwerty.co', '', '', '', NULL, NULL, NULL, '', 0, 0, '', '', '', '', 'a39274ab55aaca180da4c0def5f0932b.jpg', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `form_campos`
--

CREATE TABLE IF NOT EXISTS `form_campos` (
`id` int(11) NOT NULL,
  `id_especialista` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL,
  `campo_nombre` text CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `campo_descripcion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `campo_tipo` int(11) NOT NULL DEFAULT '0',
  `campo_area` int(11) DEFAULT NULL,
  `orden` int(2) NOT NULL DEFAULT '0',
  `activo` int(11) NOT NULL DEFAULT '0',
  `identificador` varchar(32) NOT NULL,
  `bloqueo` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `form_campos`
--

INSERT INTO `form_campos` (`id`, `id_especialista`, `id_empresa`, `campo_nombre`, `campo_descripcion`, `campo_tipo`, `campo_area`, `orden`, `activo`, `identificador`, `bloqueo`) VALUES
(0, 1, 1, 'Imagen', 'Campo para imagen', 15, 0, 0, 0, 'daee3c76ad574acc90291948fd2f802f', 0),
(28, 0, 1, 'Nombre', 'Nombre sin apellidos', 1, 0, 0, 1, '71ab36d5500505b3b706ce9bec9783eb', 0),
(29, 0, 1, 'Apellido', 'Solo el apellido', 1, 0, 0, 1, '19bd3d21cc604e9583f1c7aba0e1c512', 0),
(30, 0, 1, 'Teléfono movil', '1234567890', 3, 0, 0, 1, 'f4b6a5a6cb06b387d270caa7960339ae', 0),
(31, 0, 1, 'Teléfono fijo', '1234567890', 3, 0, 0, 1, 'bea2e8d64d161d122ab877a35f0d26d6', 0),
(32, 0, 1, 'Pais', 'País de residencia', 1, 0, 0, 1, 'd41f31b832de1c8b822c2ce599ef706f', 0),
(33, 0, 1, 'Provincia o departamento', 'Región', 1, 0, 0, 1, 'b41491e6dbc1c95384451c30b844f789', 0),
(34, 0, 1, 'Ciudad', 'Municipio o ciudad', 1, 0, 0, 1, '466059067d29095115314e1c47493996', 0),
(35, 0, 1, 'Dirección', 'Dirección de la casa o edificio', 1, 0, 0, 1, 'c6d6a1641a3bc5e596a4d5a251e5c24e', 0),
(36, 0, 1, 'Localización', 'Ubicación en el mapa', 14, 0, 0, 1, 'a4465dd45e5d214dc62c7ddab5b1f150', 0),
(37, 0, 1, 'Sexo', 'Seleccione una opción', 8, 0, 0, 1, '2e301e00acafbcbbac43206d22c7cebd', 0),
(38, 0, 1, 'Correo electrónico', 'Email o correo electrónico', 12, 0, 0, 1, '6d314e609d155d25560d3dfc082e748e', 0),
(39, 0, 1, 'Fecha de nacimiento', 'Escribe tu fecha de nacimiento', 11, 0, 0, 1, '3e74cab2b10849d473556e995c1ef437', 0),
(40, 0, 1, 'Biografía', 'Cuéntanos algo sobre ti.', 2, 0, 0, 1, '2d83aab1528827a15337340608f821b7', 0),
(41, 0, 1, 'Categoría', '', 8, 0, 0, 1, '80ec3f3eee7fd5c66026756f5682f91f', 0),
(42, 0, 1, 'Horario', '', 1, 0, 0, 1, 'fe01f451e08777c707a3ec984b4b2f99', 0),
(43, 0, 1, '¿que tan chévere eres?', 'Escoja un valor de 1 a 10', 16, 0, 0, 1, '35f8ba02640435b725454abc178dd796', 0),
(44, 0, 1, 'Lead', 'Encabezado del texto', 17, 0, 0, 1, '7dd61af2a7a9fcb4edfd9014fe4fffb1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `form_campos_valores`
--

CREATE TABLE IF NOT EXISTS `form_campos_valores` (
`id` int(11) NOT NULL,
  `id_form_campo` int(11) NOT NULL,
  `campo_valor` char(200) COLLATE utf8_spanish2_ci NOT NULL,
  `predeterminado` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `form_campos_valores`
--

INSERT INTO `form_campos_valores` (`id`, `id_form_campo`, `campo_valor`, `predeterminado`) VALUES
(1, 37, 'Hombre', '0'),
(2, 37, 'Mujer', '0'),
(3, 37, 'No determinado', '0'),
(6, 41, 'Visitante', '0'),
(7, 41, 'Funcionario', '0'),
(8, 44, '250', '0');

-- --------------------------------------------------------

--
-- Table structure for table `form_contenido_campos`
--

CREATE TABLE IF NOT EXISTS `form_contenido_campos` (
  `id_campo` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `id_form` int(2) NOT NULL,
  `obligatorio` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `prellenado` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `orden` int(2) NOT NULL COMMENT 'orden en que aparecerá cada campo en la cnsulta particular',
  `control` varchar(32) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `form_contenido_campos`
--

INSERT INTO `form_contenido_campos` (`id_campo`, `id_empresa`, `id_form`, `obligatorio`, `prellenado`, `orden`, `control`) VALUES
(28, 1, 1, '0', '0', 5, '38d0d767ef6b39f85cff05b991dff7e9'),
(29, 1, 1, '0', '0', 10, '8174d191c0fd2f64e388fed971132993'),
(38, 1, 1, '0', '0', 25, '4eb776837ee1db81559d86e71be7698d'),
(32, 1, 1, '0', '0', 40, 'cefae8b6372c1b8c923162cc8c671574'),
(33, 1, 1, '0', '0', 45, '2e543ea19b42d527c00c0703276c7849'),
(34, 1, 1, '0', '0', 50, 'c5f5fceb5d858ee6c95b309f8f660f7d'),
(35, 1, 1, '0', '0', 55, '37e0e55940df2dcabafed6e97113f639'),
(39, 1, 1, '0', '0', 20, '4cfa7aac27ef432d93c137c6a3bab794'),
(36, 1, 1, '0', '0', 60, '7be977bbb87a866b55e900514d119ae0'),
(37, 1, 1, '0', '0', 15, '2f3212efdcbe959d9f119c60a1c3a46e'),
(31, 1, 1, '0', '0', 30, 'bafdc9dbacb51d87a5f2b3e4ac0eac17'),
(30, 1, 1, '0', '0', 35, 'e9d8733e661b2fa6d334a9d9facb391f'),
(43, 1, 1, '0', '0', 70, '9f58047daf0c9c46e9c6170b174b0066'),
(41, 1, 1, '0', '0', 65, 'ef5ebae2e2fc55d0a968e753e447100c'),
(40, 1, 1, '0', '0', 75, 'd88329c9eccbca23123d9b7ba0ef7382'),
(44, 1, 1, '0', '0', 80, '37278ba69b45ded221047eaf73e31eca');

-- --------------------------------------------------------

--
-- Table structure for table `form_datos`
--

CREATE TABLE IF NOT EXISTS `form_datos` (
`id` int(11) NOT NULL,
  `id_campo` int(11) DEFAULT NULL,
  `form_id` int(3) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_empresa` int(11) NOT NULL,
  `contenido` text NOT NULL,
  `timestamp` int(20) DEFAULT NULL,
  `ip` int(10) unsigned DEFAULT NULL,
  `control` char(32) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `form_datos`
--

INSERT INTO `form_datos` (`id`, `id_campo`, `form_id`, `id_usuario`, `id_empresa`, `contenido`, `timestamp`, `ip`, `control`) VALUES
(1, 28, 1, 1, 1, 'Fredy', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(2, 29, 1, 1, 1, 'Rivera', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(3, 38, 1, 1, 1, 'fredyrivera@qwerty.co', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(4, 32, 1, 1, 1, 'Colombia', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(5, 33, 1, 1, 1, 'Quindío', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(6, 34, 1, 1, 1, 'Filandia', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(7, 35, 1, 1, 1, 'Fundación Vivirenlafinca', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(8, 39, 1, 1, 1, '1973-01-10', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(9, 36, 1, 1, 1, '-75.6328010559082 4.688410272333594 17', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(10, 37, 1, 1, 1, 'Hombre', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(11, 30, 1, 1, 1, '3044886255', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(12, 43, 1, 1, 1, '100', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(13, 41, 1, 1, 1, 'Visitante', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92'),
(14, 40, 1, 1, 1, 'Desarrollador de MILFS', 1411605178, NULL, '205715f29537f6bbcef61a2ffd73df92');

-- --------------------------------------------------------

--
-- Table structure for table `form_id`
--

CREATE TABLE IF NOT EXISTS `form_id` (
`id` int(11) NOT NULL,
  `nombre` varchar(60) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish2_ci NOT NULL,
  `activo` set('0','1') COLLATE utf8_spanish2_ci NOT NULL,
  `modificable` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '1',
  `publico` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `propietario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `orden` int(11) NOT NULL,
  `formulario_respuesta` int(3) DEFAULT NULL COMMENT 'Formulario con el que se contesta'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `form_id`
--

INSERT INTO `form_id` (`id`, `nombre`, `descripcion`, `activo`, `modificable`, `publico`, `propietario`, `id_empresa`, `creacion`, `orden`, `formulario_respuesta`) VALUES
(1, 'Contacto', 'Formulario de contacto', '1', '1', '1', 1, 1, '2014-09-25 00:23:59', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `form_tipo_campo`
--

CREATE TABLE IF NOT EXISTS `form_tipo_campo` (
`id_tipo_campo` int(11) NOT NULL,
  `tipo_campo_nombre` text NOT NULL,
  `tipo_campo_accion` text NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `form_tipo_campo`
--

INSERT INTO `form_tipo_campo` (`id_tipo_campo`, `tipo_campo_nombre`, `tipo_campo_accion`, `activo`) VALUES
(1, 'Texto', 'text', 1),
(2, 'Nota', 'textarea', 1),
(3, 'Numérico', 'number', 1),
(8, 'Select', 'select', 1),
(11, 'Fecha', 'date', 1),
(12, 'Email', 'email', 1),
(13, 'Email envío', 'envio', 1),
(14, 'Mapa', 'mapa', 1),
(15, 'Imagen', 'imagen', 0),
(16, 'Rango', 'rango', 1),
(17, 'Texto limitado', 'limit', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
`id` int(32) NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `passwd` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `id_grupo` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `email` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `adddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(3) NOT NULL DEFAULT '0',
  `lastip` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `lastdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `p_nombre` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `s_nombre` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `p_apellido` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `s_apellido` varchar(255) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `nombre_completo` varchar(254) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '',
  `fecha_nacimiento` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `documento_tipo` int(11) NOT NULL DEFAULT '0',
  `documento_numero` char(20) CHARACTER SET latin1 NOT NULL,
  `documento_expedicion` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `control` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `firma_recuperacion` char(40) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `genero` set('M','F') CHARACTER SET latin1 NOT NULL DEFAULT '',
  `cargo` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `fotografia` char(36) COLLATE utf8_spanish2_ci NOT NULL,
  `licencia` text COLLATE utf8_spanish2_ci NOT NULL,
  `licencia_fecha` int(20) DEFAULT '0',
  `bio` longtext COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=26971 ;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `passwd`, `id_grupo`, `id_empresa`, `email`, `adddate`, `status`, `lastip`, `lastdate`, `p_nombre`, `s_nombre`, `p_apellido`, `s_apellido`, `nombre_completo`, `fecha_nacimiento`, `documento_tipo`, `documento_numero`, `documento_expedicion`, `control`, `firma_recuperacion`, `genero`, `cargo`, `fotografia`, `licencia`, `licencia_fecha`, `bio`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 0, 1, 'proyectos@qwerty.co', '2014-09-15 22:58:45', 1, '', '0000-00-00 00:00:00', NULL, NULL, NULL, '', '', '', 0, '', '', NULL, '', '', '', '', '', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `empresa`
--
ALTER TABLE `empresa`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_campos`
--
ALTER TABLE `form_campos`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `identificador` (`identificador`);

--
-- Indexes for table `form_campos_valores`
--
ALTER TABLE `form_campos_valores`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_contenido_campos`
--
ALTER TABLE `form_contenido_campos`
 ADD UNIQUE KEY `control` (`control`);

--
-- Indexes for table `form_datos`
--
ALTER TABLE `form_datos`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`), ADD KEY `control` (`control`), ADD KEY `id_campo` (`id_campo`), ADD KEY `perfil` (`form_id`), ADD KEY `id_usuario` (`id_usuario`);

--
-- Indexes for table `form_id`
--
ALTER TABLE `form_id`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_tipo_campo`
--
ALTER TABLE `form_tipo_campo`
 ADD PRIMARY KEY (`id_tipo_campo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `empresa`
--
ALTER TABLE `empresa`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `form_campos`
--
ALTER TABLE `form_campos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `form_campos_valores`
--
ALTER TABLE `form_campos_valores`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `form_datos`
--
ALTER TABLE `form_datos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `form_id`
--
ALTER TABLE `form_id`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `form_tipo_campo`
--
ALTER TABLE `form_tipo_campo`
MODIFY `id_tipo_campo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
MODIFY `id` int(32) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26971;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
