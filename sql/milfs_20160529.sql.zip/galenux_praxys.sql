-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 29, 2016 at 11:11 AM
-- Server version: 5.5.49-0+deb8u1
-- PHP Version: 5.6.20-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `galenux_praxys`
--

-- --------------------------------------------------------

--
-- Table structure for table `empresa`
--

CREATE TABLE IF NOT EXISTS `empresa` (
`id` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL DEFAULT '0' COMMENT 'Se guarda el id del responsable de la empresa',
  `ciiu` char(5) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `sector` int(3) NOT NULL,
  `razon_social` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `sigla` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `slogan` text CHARACTER SET latin1 NOT NULL,
  `nit` varchar(15) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `direccion` text CHARACTER SET latin1 NOT NULL,
  `telefono_1` varchar(30) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `web` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `email` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `persona_contacto` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `regimen_tributario` char(15) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `resolucion_facturacion` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `facturacion_desde` int(30) DEFAULT NULL COMMENT 'Comienzo del permiso de facturación',
  `facturacion_hasta` int(30) DEFAULT NULL COMMENT 'Fin del permiso de facturación',
  `facturacion_primera` int(30) DEFAULT NULL COMMENT 'Primera factura que se imprimirá, puede ser la primera de la resolución',
  `facturacion_prefijo` varchar(25) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `facturacion_fecha` int(20) NOT NULL DEFAULT '0' COMMENT 'Fechad e la resolucion',
  `facturacion_vencimiento` int(20) NOT NULL DEFAULT '0' COMMENT 'Fecha de vencimiento de la resolucion de facturación',
  `logo_color` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_bn` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_alta` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo_baja` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `imagen` char(40) COLLATE utf8_spanish2_ci NOT NULL,
  `css` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `css_impresion` varchar(254) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `id_localizacion` int(11) NOT NULL,
  `id_redes_sociales` int(11) NOT NULL,
  `estado` int(1) NOT NULL DEFAULT '1',
  `facebook` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `twitter` varchar(100) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci COMMENT='Datos de la IPS';

--
-- Dumping data for table `empresa`
--

INSERT INTO `empresa` (`id`, `id_responsable`, `ciiu`, `sector`, `razon_social`, `sigla`, `slogan`, `nit`, `direccion`, `telefono_1`, `web`, `email`, `persona_contacto`, `regimen_tributario`, `resolucion_facturacion`, `facturacion_desde`, `facturacion_hasta`, `facturacion_primera`, `facturacion_prefijo`, `facturacion_fecha`, `facturacion_vencimiento`, `logo_color`, `logo_bn`, `logo_alta`, `logo_baja`, `imagen`, `css`, `css_impresion`, `id_localizacion`, `id_redes_sociales`, `estado`, `facebook`, `twitter`) VALUES
(1, 0, '', 0, 'MILF', '', 'Activismo de datos\n			 	\n			 	', '', 'Colombia\n			 	', '+57000123456', 'qwerty.co', 'correo@qwerty.co', '', '', '', NULL, NULL, NULL, '', 0, 0, '', '', '', '', 'da6d16547658ebc06c5378b30d1ee4bf.png', '', '', 0, 0, 1, 'tupaleco', 'tupaleco');

-- --------------------------------------------------------

--
-- Table structure for table `form_areas`
--

CREATE TABLE IF NOT EXISTS `form_areas` (
`id` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `descripcion` text NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '0',
  `orden` int(11) NOT NULL DEFAULT '0' COMMENT 'Orden en que se muestran las areas',
  `id_empresa` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_areas`
--

INSERT INTO `form_areas` (`id`, `nombre`, `descripcion`, `estado`, `orden`, `id_empresa`) VALUES
(1, 'General', 'area general', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `form_campos`
--

CREATE TABLE IF NOT EXISTS `form_campos` (
`id` int(11) NOT NULL,
  `id_especialista` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL,
  `campo_nombre` text CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `campo_descripcion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `campo_tipo` int(11) NOT NULL DEFAULT '0',
  `campo_area` int(11) DEFAULT NULL,
  `orden` int(2) NOT NULL DEFAULT '0',
  `activo` int(11) NOT NULL DEFAULT '0',
  `identificador` varchar(32) NOT NULL,
  `bloqueo` int(1) NOT NULL DEFAULT '0',
  `tipo_contenido` set('1','a','s') NOT NULL COMMENT '''1 numerico'',''alfanumerico'',''simbolos'''
) ENGINE=InnoDB AUTO_INCREMENT=788 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_campos`
--

INSERT INTO `form_campos` (`id`, `id_especialista`, `id_empresa`, `campo_nombre`, `campo_descripcion`, `campo_tipo`, `campo_area`, `orden`, `activo`, `identificador`, `bloqueo`, `tipo_contenido`) VALUES
(0, 1, 1, 'imagen', 'imagen', 15, 1, 0, 1, 'imagen', 0, ''),
(1, 1, 1, 'Primer nombre', 'Pablo', 1, 1, 0, 1, 'f13bb435acfd7ba3f88a5f74fe3fadc2', 0, ''),
(2, 1, 1, 'Segundo nombre', 'Fernando', 1, 1, 0, 1, 'e03db6f72422a01b20953b25d7c7fee3', 0, ''),
(3, 1, 1, 'Primer apellido', 'Perez', 1, 1, 0, 1, '5c3cdc8e15eb15dfce8c591986deb800', 0, ''),
(4, 1, 1, 'Segundo apellido', 'Martinez', 1, 1, 0, 1, 'bc1699111bd9aa3b3ec114f53f99a3cb', 0, ''),
(5, 1, 1, 'Nombres y apellidos', 'Escriba el nombre completo con apellidos', 1, 1, 0, 1, '531a7eaef7ed326a6222e2aeb1229e9c', 0, ''),
(6, 1, 1, 'Telefono', 'Solo números', 3, 1, 0, 1, '4a70495abb15d926dcc031e58b67fbe4', 0, ''),
(7, 1, 1, 'Dirección', 'Escriba la dirección completa', 1, 1, 0, 1, '400864ef5b72242c7aa78edaa83854f3', 0, ''),
(8, 1, 1, 'Actividad', '', 1, 1, 0, 1, 'e92ff0595452708abc9e7bfe698eafd1', 0, ''),
(9, 1, 1, 'Descripcion', '', 2, 1, 0, 1, '34b1a570180e02f1960e7d7a25e23002', 0, ''),
(10, 1, 1, 'Mes', 'Los meses del año', 8, 1, 0, 1, '400ba32128df67eb162fb753e8cfad4c', 0, ''),
(11, 1, 1, 'Entidad', 'Nombre de la entidad.', 1, 1, 0, 1, '9141fdf92fbed44d18789854b537868e', 0, ''),
(12, 1, 1, 'Cargo', 'Cargo que ocupa en la institución\n			 	', 1, 1, 0, 1, '16011685a8337f9c38e988652969a96f', 0, ''),
(13, 1, 1, 'Celular', 'Numero de celular.', 3, 1, 0, 1, '1a9ca006b88f96785ca15a6165e813ff', 0, ''),
(14, 1, 1, 'Categoria', 'Categoria para los contactos del museo ', 8, 1, 0, 1, '1852d58951a6980771d9ee7ba189722a', 0, ''),
(15, 1, 1, 'Correo electronico', 'Correo electronico', 1, 1, 0, 1, 'dd9fc13c87ca1fbde986c92c131e6b5d', 0, ''),
(16, 1, 1, 'Correo electronico secundario', 'Correo Electronico Secundario, si la persona tiene un segundo correo este campo puede ser útil.', 1, 1, 0, 1, '65e752c9c88fdfba3a1eea293a89e4f3', 0, ''),
(787, 1, 1, 'Mensaje', 'Escribe un mensaje', 2, 1, 0, 1, '4699bffaa9e5f806772b1354b394b9ae', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `form_campos_valores`
--

CREATE TABLE IF NOT EXISTS `form_campos_valores` (
`id` int(11) NOT NULL,
  `id_form_campo` int(11) NOT NULL,
  `campo_valor` text COLLATE utf8_spanish2_ci NOT NULL,
  `predeterminado` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=7504 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `form_campos_valores`
--

INSERT INTO `form_campos_valores` (`id`, `id_form_campo`, `campo_valor`, `predeterminado`) VALUES
(1, 10, 'Enero', '0'),
(2, 10, 'Febrero', '0'),
(3, 10, 'Marzo', '0'),
(4, 10, 'Abril', '0'),
(5, 10, 'Mayo', '0'),
(6, 10, 'Junio', '0'),
(7, 10, 'Julio', '0'),
(8, 10, 'Agosto', '0'),
(9, 10, 'Septiembre', '0'),
(10, 10, 'Octubre', '0'),
(11, 10, 'Noviembre', '0'),
(12, 10, 'Diciembre', '0'),
(137, 14, 'Medio local', '0'),
(138, 14, 'Organizaciones de victimas', '0'),
(139, 14, 'Cooperación', '0'),
(140, 14, 'Amigo', '0'),
(141, 14, 'Privado', '0'),
(142, 14, 'Ong', '0'),
(143, 14, 'Museo', '0'),
(144, 14, 'Entidad pública', '0'),
(145, 14, 'Gobierno', '0'),
(146, 14, 'Mcm', '0'),
(147, 14, 'Medios', '0'),
(148, 14, 'Amigo', '0'),
(149, 14, 'Particular', '0'),
(150, 14, 'Jal', '0'),
(151, 14, 'Privado', '0'),
(152, 14, 'Comité asesor', '0'),
(153, 14, 'Grupo juvenil', '0'),
(154, 14, 'Instituciones educativas', '0'),
(155, 14, 'Artistas', '0'),
(156, 14, 'Artista', '0'),
(157, 14, 'Medio internacional', '0'),
(158, 14, 'Cultura', '0'),
(159, 14, 'Apoyo', '0'),
(160, 14, 'Universidades', '0'),
(161, 14, 'Músicos', '0'),
(162, 14, 'Bibliotecas', '0'),
(163, 14, 'Cooperación', '0'),
(164, 14, 'Policía nacional', '0'),
(165, 14, 'Visitante', '0'),
(166, 14, 'Internacional', '0'),
(167, 14, 'Universidad', '0'),
(168, 14, 'Estudiante', '0'),
(169, 14, 'Académico', '0'),
(170, 14, 'Contratistas', '0'),
(171, 14, 'Organización artistica', '0'),
(172, 14, 'Organización académica y cultural', '0'),
(173, 14, 'Organización cultural', '0'),
(174, 14, 'Organización social', '0'),
(175, 14, 'Educativa y cultural', '0'),
(176, 14, 'Organización social', '0'),
(177, 14, 'Independiente', '0');

-- --------------------------------------------------------

--
-- Table structure for table `form_contenido_campos`
--

CREATE TABLE IF NOT EXISTS `form_contenido_campos` (
`id` int(11) NOT NULL,
  `id_campo` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `id_form` int(2) NOT NULL,
  `obligatorio` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `multiple` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `orden` int(2) NOT NULL COMMENT 'orden en que aparecerá cada campo en la cnsulta particular',
  `control` varchar(32) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `form_contenido_campos`
--

INSERT INTO `form_contenido_campos` (`id`, `id_campo`, `id_empresa`, `id_form`, `obligatorio`, `multiple`, `orden`, `control`) VALUES
(1, 5, 1, 1, '0', '0', 1, 'b00e2ad8d58a1d8fc596a09dbd9699ab'),
(2, 13, 1, 1, '0', '0', 2, '66b244c5176e6c1a7ae411a443066e42'),
(3, 15, 1, 1, '0', '0', 3, 'fc66c997dee619ddab9486e56e193f2f'),
(4, 11, 1, 1, '0', '0', 4, '77ed5097ec8c88d4b6af11bb84923cd0'),
(5, 12, 1, 1, '0', '0', 5, '7f4b9166cc5a966edcc3270c9c31d1d8'),
(6, 7, 1, 1, '0', '0', 6, '1f679278f0a4e644793b8b6a97a50275'),
(7, 787, 1, 1, '0', '0', 7, '7a22c92e9368651f017e8c7a55926e8e');

-- --------------------------------------------------------

--
-- Table structure for table `form_datos`
--

CREATE TABLE IF NOT EXISTS `form_datos` (
`id` int(11) NOT NULL,
  `id_campo` int(11) DEFAULT NULL,
  `form_id` int(3) DEFAULT NULL,
  `proceso` int(11) DEFAULT NULL,
  `orden` int(11) NOT NULL DEFAULT '0',
  `id_usuario` char(32) COLLATE utf8_bin DEFAULT NULL,
  `id_empresa` int(11) NOT NULL,
  `contenido` longtext COLLATE utf8_bin NOT NULL,
  `timestamp` int(20) DEFAULT NULL,
  `ip` int(10) unsigned DEFAULT NULL,
  `control` char(32) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `form_grupo`
--

CREATE TABLE IF NOT EXISTS `form_grupo` (
`id_grupo` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `grupo` text NOT NULL,
  `id_empresa` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_grupo`
--

INSERT INTO `form_grupo` (`id_grupo`, `id`, `grupo`, `id_empresa`) VALUES
(1, 1, 'Contacto', 1);

-- --------------------------------------------------------

--
-- Table structure for table `form_id`
--

CREATE TABLE IF NOT EXISTS `form_id` (
`id` int(11) NOT NULL,
  `nombre` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `descripcion` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `activo` set('0','1') COLLATE utf8_spanish2_ci NOT NULL,
  `modificable` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '1',
  `publico` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `propietario` char(32) COLLATE utf8_spanish2_ci NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `orden` int(11) NOT NULL,
  `formulario_respuesta` int(3) DEFAULT NULL COMMENT 'Formulario con el que se contesta'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `form_id`
--

INSERT INTO `form_id` (`id`, `nombre`, `descripcion`, `activo`, `modificable`, `publico`, `propietario`, `id_empresa`, `creacion`, `orden`, `formulario_respuesta`) VALUES
(1, 'Contacto', '			 	', '1', '1', '0', '1', 1, '2016-05-29 12:54:47', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `form_interacciones`
--

CREATE TABLE IF NOT EXISTS `form_interacciones` (
`id` int(11) NOT NULL,
  `identificador` char(32) NOT NULL,
  `tipo` char(32) NOT NULL,
  `ip` int(10) DEFAULT NULL,
  `usuario` char(32) NOT NULL,
  `mensaje` text NOT NULL,
  `estado` int(1) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `form_parametrizacion`
--

CREATE TABLE IF NOT EXISTS `form_parametrizacion` (
`id` int(11) NOT NULL,
  `tabla` varchar(32) NOT NULL,
  `campo` varchar(32) NOT NULL,
  `item` char(32) NOT NULL,
  `opcion` varchar(200) NOT NULL,
  `descripcion` longtext NOT NULL,
  `visible` set('0','1') NOT NULL DEFAULT '1',
  `id_empresa` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_parametrizacion`
--

INSERT INTO `form_parametrizacion` (`id`, `tabla`, `campo`, `item`, `opcion`, `descripcion`, `visible`, `id_empresa`) VALUES
(1, 'form_id', '1', '', 'mensaje_envio', 'Gracias por estar en contacto', '1', 1),
(2, 'form_id', '1', '', 'email', 'correo@qwerty.co', '1', 1),
(3, 'form_id', '1', '', 'formulario', '97', '1', NULL),
(4, 'form_id', 'dsfd', '', 'formulario', '1', '1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `form_permisos`
--

CREATE TABLE IF NOT EXISTS `form_permisos` (
`id` int(11) NOT NULL,
  `control` char(32) NOT NULL,
  `permiso` char(40) NOT NULL,
  `vencimiento` int(20) NOT NULL,
  `creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` char(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `form_tipo_campo`
--

CREATE TABLE IF NOT EXISTS `form_tipo_campo` (
`id_tipo_campo` int(11) NOT NULL,
  `tipo_campo_nombre` text NOT NULL,
  `tipo_campo_accion` text NOT NULL,
  `descripcion` text NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_tipo_campo`
--

INSERT INTO `form_tipo_campo` (`id_tipo_campo`, `tipo_campo_nombre`, `tipo_campo_accion`, `descripcion`, `activo`) VALUES
(1, 'Texto', 'text', '', 1),
(2, 'Nota', 'textarea', '', 1),
(3, 'Numérico', 'number', '', 1),
(4, 'URL', 'url', '', 1),
(5, 'Medio', 'media', '', 1),
(6, 'Buscador', 'buscador', '', 1),
(7, 'HTML', 'html', '', 1),
(8, 'Select', 'select', '', 1),
(9, 'Combo select', 'combo', '', 1),
(10, 'Relación', 'relacion', '', 1),
(11, 'Fecha', 'date', '', 1),
(12, 'Email', 'email', '', 1),
(13, 'Email envío', 'envio', '', 1),
(14, 'Mapa', 'mapa', '', 1),
(15, 'Imagen', 'imagen', '', 1),
(16, 'Rango', 'rango', '', 1),
(17, 'Texto limitado', 'limit', '', 1),
(18, 'Password', 'password', '', 1),
(19, 'Campo único', 'unico', '', 1),
(20, 'Campo oculto', 'oculto', '', 1),
(21, 'Base de datos', 'base', '', 1),
(22, 'Timestamp', 'timestamp', '', 1),
(23, 'Funcion', 'oculto', '', 1),
(24, 'Checkbox', 'checkbox', 'Casa,Carro,Beca:1', 1),
(25, 'Radio', 'radio', 'Acepto,No acepto,No me importa', 1),
(26, 'Formulario vinculado', 'vinculado', 'Escriba el ID del formulario que desea vincular y este aparecerá en lugar del campo.', 1),
(27, 'Radio agrupado linea', 'radio_agrupado_linea', 'Rojo,Verde,Azul', 1),
(28, 'Radio agrupado campos', 'radio_agrupado_campos', 'Escriba el listado de id_campo que va a agrupar eje. 175,180', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
`id` int(32) NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `passwd` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `id_grupo` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `email` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `adddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(3) NOT NULL DEFAULT '0',
  `lastip` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `lastdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `p_nombre` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `s_nombre` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `p_apellido` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `s_apellido` varchar(255) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `nombre_completo` varchar(254) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '',
  `fecha_nacimiento` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `documento_tipo` int(11) NOT NULL DEFAULT '0',
  `documento_numero` char(20) CHARACTER SET latin1 NOT NULL,
  `documento_expedicion` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `control` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `firma_recuperacion` char(40) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `genero` set('M','F') CHARACTER SET latin1 NOT NULL DEFAULT '',
  `cargo` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `fotografia` char(36) COLLATE utf8_spanish2_ci NOT NULL,
  `licencia` text COLLATE utf8_spanish2_ci NOT NULL,
  `licencia_fecha` int(20) DEFAULT '0',
  `bio` longtext COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=27026 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `passwd`, `id_grupo`, `id_empresa`, `email`, `adddate`, `status`, `lastip`, `lastdate`, `p_nombre`, `s_nombre`, `p_apellido`, `s_apellido`, `nombre_completo`, `fecha_nacimiento`, `documento_tipo`, `documento_numero`, `documento_expedicion`, `control`, `firma_recuperacion`, `genero`, `cargo`, `fotografia`, `licencia`, `licencia_fecha`, `bio`) VALUES
(1, 'Desadministrador', '4e6336c8f0b3a5e57164706d4ae51e45', 1, 1, 'correo@qwerty.co', '2014-09-15 22:58:45', 1, '', '0000-00-00 00:00:00', 'Desadministrador', NULL, 'del demonio', '', '', '', 0, '', '', NULL, '', '', '', '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios_grupo`
--

CREATE TABLE IF NOT EXISTS `usuarios_grupo` (
  `id` int(11) NOT NULL,
  `grupo_nombre` varchar(255) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `descripcion_grupo` text COLLATE utf8_spanish2_ci NOT NULL,
  `asistencial` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0' COMMENT '1 Asistencial, 0 NO es asistencial',
  `prioridad` int(11) NOT NULL DEFAULT '0',
  `tabla` varchar(60) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `inactivo` set('0','1') COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0' COMMENT '1 el grupo esta inactivo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci COMMENT='grupos y prioridades a los que puede pertenecer un usuario';

--
-- Dumping data for table `usuarios_grupo`
--

INSERT INTO `usuarios_grupo` (`id`, `grupo_nombre`, `descripcion_grupo`, `asistencial`, `prioridad`, `tabla`, `inactivo`) VALUES
(0, 'Inactivo', 'Usuarios que ya no pueden ingresar al sistema', '0', 0, '', '0'),
(1, 'Administrador', 'Super usuario del sistema', '1', 5, '', '1'),
(2, 'Paciente', 'Personas que acuden a consulta', '0', 2, '', '0'),
(3, 'Especialista', 'Oncologos y demás especialistas', '1', 3, 'especialistas', '0'),
(4, 'Asistencial', 'Personal de enfermeria', '1', 3, 'especialistas', '0'),
(5, 'Administrativo', 'Personal que regularmente realiza trabajo de oficina', '0', 5, '', '0'),
(6, 'Cliente', 'Eps o aseguradora', '0', 0, 'clientes', '1'),
(7, 'Admisiones', 'Admisiones, Atencion de llamadas y asignacion de citas', '0', 5, '', '0'),
(8, 'Triage', 'Medico o personal asistencial que realiza el triage', '0', 3, 'especialistas', '1'),
(9, 'Almacén', 'Procesos relacionados con el manejo del inventario', '0', 5, '', '0'),
(10, 'Facturación', 'Revisa, emite, envía e imprime factura', '0', 5, '', '1'),
(11, 'Auditoria Medica', 'Revisa usuarios y consultas médicas incluyendo historias clinicas', '1', 3, '', '0'),
(12, 'Revisoría fiscal', 'Revision fiscal para la conabilidad', '0', 2, '', '0'),
(13, 'Farmacia', 'Procesos relacionados con la atención farmaceutica', '0', 3, '', '0'),
(14, 'Central de mezclas', 'Proceso y transformación de productos', '0', 3, '', '0'),
(15, 'Facturacion', 'Facturacion', '0', 5, '', '0'),
(16, 'Promoción y prevención', 'Personal de promoción y prevención que tienen acceso a procesos administrativos y asistenciales.', '1', 3, 'especialistas', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `empresa`
--
ALTER TABLE `empresa`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_areas`
--
ALTER TABLE `form_areas`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_campos`
--
ALTER TABLE `form_campos`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `identificador` (`identificador`);

--
-- Indexes for table `form_campos_valores`
--
ALTER TABLE `form_campos_valores`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_contenido_campos`
--
ALTER TABLE `form_contenido_campos`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `control` (`control`);

--
-- Indexes for table `form_datos`
--
ALTER TABLE `form_datos`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`), ADD KEY `control` (`control`), ADD KEY `id_campo` (`id_campo`), ADD KEY `perfil` (`form_id`), ADD KEY `id_usuario` (`id_usuario`);

--
-- Indexes for table `form_grupo`
--
ALTER TABLE `form_grupo`
 ADD PRIMARY KEY (`id_grupo`);

--
-- Indexes for table `form_id`
--
ALTER TABLE `form_id`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_interacciones`
--
ALTER TABLE `form_interacciones`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_parametrizacion`
--
ALTER TABLE `form_parametrizacion`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Indexes for table `form_permisos`
--
ALTER TABLE `form_permisos`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_tipo_campo`
--
ALTER TABLE `form_tipo_campo`
 ADD PRIMARY KEY (`id_tipo_campo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `usuarios_grupo`
--
ALTER TABLE `usuarios_grupo`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `empresa`
--
ALTER TABLE `empresa`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `form_areas`
--
ALTER TABLE `form_areas`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `form_campos`
--
ALTER TABLE `form_campos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=788;
--
-- AUTO_INCREMENT for table `form_campos_valores`
--
ALTER TABLE `form_campos_valores`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7504;
--
-- AUTO_INCREMENT for table `form_contenido_campos`
--
ALTER TABLE `form_contenido_campos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `form_datos`
--
ALTER TABLE `form_datos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `form_grupo`
--
ALTER TABLE `form_grupo`
MODIFY `id_grupo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `form_id`
--
ALTER TABLE `form_id`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `form_interacciones`
--
ALTER TABLE `form_interacciones`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `form_parametrizacion`
--
ALTER TABLE `form_parametrizacion`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `form_permisos`
--
ALTER TABLE `form_permisos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `form_tipo_campo`
--
ALTER TABLE `form_tipo_campo`
MODIFY `id_tipo_campo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
MODIFY `id` int(32) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27026;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
